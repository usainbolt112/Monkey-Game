var monkey, monkey_moving
var banana, bananaImage;
var obstacle, obstacleImage, obstaclesGroup;
var background, backgroundImage;
var score;
function preload(){
  backgroundImage=loadImage("");
}
function setup() {
  createCanvas(400, 400);
  monkey = createSprite(50,180,20,50);
  monkey.addAnimation("", monkey_moving);
  monkey.scale = 0.5;
  
  background = createSprite(200,200,400,400);
  background.addImage("",backgroundImage);
  background.x = background.width /2;
  background.velocityX = -6;
  
  ground=createSprite((200,380,400,10));
  ground.visible = false;
  
}

function draw() {
  background(220);
  if(banana_isTouching(monkey)){
    score=score+2
  }
  if(banana_isTouching(monkey))
  {banana.visible=false}
if(obstaclesGroup_isTouching(monkey)){
monkey.scale=0.5
}
  
}